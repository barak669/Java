package interfaces;

public interface Imammal {

	public int getdayOfBirth();
	
}
