package interfaces;

public interface Ireptile {

	public boolean getPosion();
}
