
public interface IFamilyStudent {
	
	public int getLevel();
	public void setLevel(int level);
	
	
}
