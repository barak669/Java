
public interface IScholarshipStudent {
	public int getScholarship_sum();
	public void setScholarship_sum(int scholarship_sum);
}
