import java.util.ArrayList;
import java.util.Scanner;

public class ClassMain {

	public static void cheapest(ArrayList < Shop > arr , double b, double a , double o)
	{
		Shop shop = arr.get(0);
		
		double min = arr.get(0).getBanana()*b + arr.get(0).getApple()*a+ arr.get(0).getOrange()*o;
		
		for(Shop s : arr)
		{
			if(min > s.getApple()*a + s.getBanana()*b + s.getOrange()*o)
			{
				shop = s;
				min = s.getApple()*a + s.getBanana()*b + s.getOrange()*o;
			}
			
		}
		shop.print();
		
	}
	public static void main ( String[] argv)
	{
		Scanner input = new Scanner(System.in);
		ArrayList<Shop> arr = new ArrayList<Shop>();
		
		for ( int i=0 ; i<12 ; i++)
		{
			System.out.println("enter name");
			String name = input.nextLine();
			
			System.out.println("enter orange price");
			double orange = input.nextDouble();
			
			System.out.println("enter apple price");
			double apple = input.nextDouble();
			
			System.out.println("enter banana price");
			double banana = input.nextDouble();
			
			arr.add(new Shop(name ,apple, banana , orange));
		}
		cheapest(arr, 3,4,5);
		
	}

}
