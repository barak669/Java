
public class Shop {

	double apple;
	String name; 
	double banana;
	double orange;
	
	public Shop ( String name , double apple , double banana , double orange)
	{
		this.apple = apple;
		this.name = name;
		this.banana = banana;
		this.orange = orange;
		
	}
	
	
	public String getName()
	{
		return name;
	}
	public double getBanana()
	{
		return banana;
	}
	public double getOrange()
	{
		return orange;
	}
	public double getApple()
	{
		return apple;
	}
	public void setData ( String name , double apple , double banana , double orange)
	{
		this.apple = apple;
		this.name = name;
		this.banana = banana;
		this.orange = orange;
		
	}
	public void print()
	{
		System.out.println(name +" "+ banana + " " + orange + " " + apple);
	}
}
